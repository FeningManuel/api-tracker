package org.tracker;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TaskService {
    public static void main(String[] args) {
        // Create a list to store Task objects
        List<Task> tasks = new ArrayList<>();

        // Create and add Task objects to the list
        Task task1 = new Task(1, "Task 1", "Description 1", "complete");
        Task task2 = new Task(2, "Task 2", "Description 2", "incomplete");

        tasks.add(task1);
        tasks.add(task2);

        // Print the list of tasks
        for (Task task : tasks) {
            System.out.println(task);
        }
    }

	    // Retrieve all tasks
	    public List<Task> getAllTasks() {
	        List<Task> tasks = null;
			return tasks;
	    }

	    // Retrieve a specific task by its ID
	    @SuppressWarnings("null")
		public Optional<Task> getTaskById(long id) {
	        Collection<Task> tasks = null;
			return tasks.stream().filter(task -> task.getId() == id).findFirst();
	    }

	    // Update an existing task
	    public boolean updateTask(long id, Task updatedTask) {
	        Optional<Task> existingTask = getTaskById(id);
	        if (existingTask.isPresent()) {
	            Task taskToUpdate = existingTask.get();
	            taskToUpdate.setTitle(updatedTask.getTitle());
	            taskToUpdate.setDescription(updatedTask.getDescription());
	            taskToUpdate.setStatus(updatedTask.getStatus());
	            return true; // Task updated successfully
	        }
	        return false; // Task with the given ID not found
	    }

	    // Delete a task by its ID
	    @SuppressWarnings("null")
		public boolean deleteTask(long id) {
	        Optional<Task> taskToDelete = getTaskById(id);
	        if (taskToDelete.isPresent()) {
	            List<Task> tasks = null;
				tasks.remove(taskToDelete.get());
	            return true; // Task deleted successfully
	        }
	        return false; // Task with the given ID not found
	    }

	    @SuppressWarnings("null")
		public Task createTask(Task task) {
	        int nextTaskId = 0;
			// Assign a unique ID to the task
	        task.setId(nextTaskId++);
	        
	        List<Task> tasks = null;
			// Add the task to the list of tasks
	        tasks.add(task);
	        
	        // Return the created task
	        return task;
	    }

}
