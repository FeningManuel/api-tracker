package org.tracker;

import java.util.List;
import java.util.Optional;

import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/tasks")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class TaskResource {
    @Inject
    TaskService taskService;
    
   
    // GET /tasks - Retrieve a list of all tasks
    @GET
    public List<Task> getAllTasks() {
        return taskService.getAllTasks();
    }

    // GET /tasks/{id} - Retrieve a specific task by its ID
    @GET
    @Path("/{id}")
    public Task getTaskById(@PathParam("id") long id) {
        Optional<Task> task = taskService.getTaskById(id);
        if (task.isPresent()) {
            return task.get();
        } else {
            throw new NotFoundException("Task with ID " + id + " not found");
        }
    }

    // POST /tasks - Create a new task
    @POST
    public Task createTask(Task task) {
        return taskService.createTask(task);
    }

    // PUT /tasks/{id} - Update an existing task by its ID
    @PUT
    @Path("/{id}")
    public Task updateTask(@PathParam("id") long id, Task task) {
        if (taskService.updateTask(id, task)) {
            return task;
        } else {
            throw new NotFoundException("Task with ID " + id + " not found");
        }
    }

    // DELETE /tasks/{id} - Delete a task by its ID
    @DELETE
    @Path("/{id}")
    public void deleteTask(@PathParam("id") long id) {
        if (!taskService.deleteTask(id)) {
            throw new NotFoundException("Task with ID " + id + " not found");
        }
    }

}
